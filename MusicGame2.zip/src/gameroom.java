// import java.awt.Font;
//import java.awt.Graphics;
//import java.awt.Image;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//import javax.swing.ImageIcon;
//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JLabel;
import java.util.Timer;
import java.util.TimerTask;

public class gameroom extends JFrame{

	String title;
	int time;
	Image screan;
	Graphics screang;
    game gm; 
	
	
	JButton Button  = new JButton(new ImageIcon("image/back.jpg"));

	gameroom(String title, int time){
		
	this.title = title;
	gm = new game(title);
	this.time = time;
	
	setTitle("����");
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setResizable(false); // ũ�����
	setSize(600, 500);
	setLocationRelativeTo(null); // �߾�
	setVisible(true);
	
	

	addKeyListener(new key());

	setLayout(null);
	
	// ���� ���۽��� ���� Ÿ�̸�
	Timer m=new Timer();
	TimerTask m_t = new TimerTask() {
		public void run() {
			gm.g_mu.close();
			new result(); //���â ���
			dispose(); // â�ݱ�
			
		}
	};
	m.schedule(m_t, time + 2000); // ���� �ð��� 2�� +
	

}
	
	// ����Ʈ- �׸� �׸��� �۾� -> ���� ��Ʃ��(������� ���� ����)
public void paint (Graphics g) {
		screan = createImage(600, 500);
		screang = screan.getGraphics();
		screanDraw((Graphics2D)screang);
		g.drawImage(screan, 0, 0, null);
	}
	
	public void screanDraw(Graphics2D g) {
		
			paintComponents(g);
	
			gm.screenDraw(g);
	
			this.repaint();
	
	}
	
	class key implements KeyListener{ // Ű �Է¿� ���� �̺�Ʈ ó��

		@Override
		public void keyPressed(KeyEvent e) {
			
	if(e.getKeyCode() == KeyEvent.VK_D) {
		
		gm.d();
			
			}
	else if(e.getKeyCode() == KeyEvent.VK_F) {
		gm.f();
	}
	else if(e.getKeyCode() == KeyEvent.VK_SPACE) {
		
		gm.space();
	}
	else if(e.getKeyCode() == KeyEvent.VK_J) {
		gm.j();
	}
	else if(e.getKeyCode() == KeyEvent.VK_K) {
	gm.k();
	}
			
		}

		@Override
		public void keyReleased(KeyEvent e) { // Ű�� ���� ���� �̺�Ʈ ó��
	if(e.getKeyCode() == KeyEvent.VK_D) {
	gm.dr();
			
			}
	else if(e.getKeyCode() == KeyEvent.VK_F) {
	gm.fr();
	}
	else if(e.getKeyCode() == KeyEvent.VK_SPACE) {
	gm.spacer();
	}
	else if(e.getKeyCode() == KeyEvent.VK_J) {
	gm.jr();
	}
	else if(e.getKeyCode() == KeyEvent.VK_K) {
	gm.kr();
	}
			
		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}

	
}


