
public class track {

	String title; //  ���� 
	String startimage ; // ���� image
	int time;
	String music;
	
	track(String title, String startimage, String music, int time){
		this.title = title;
		this.startimage = startimage;
				this.time = time;
				this.music = music;
	}
	
	
	
}
