import java.util.ArrayList;

public class note2 {
	ArrayList<block> blocklist = new ArrayList<>();

	// Call Ʈ�� ����
	note2(){
		blocklist.add(new block(135, 500));
		blocklist.add(new block(135, 1000));
		blocklist.add(new block(245, 1500));
		blocklist.add(new block(355, 2000));
		blocklist.add(new block(25, 2000));
		blocklist.add(new block(355, 2500));
		blocklist.add(new block(245, 2700));
		blocklist.add(new block(135, 2900));
		blocklist.add(new block(25, 3100));
		blocklist.add(new block(355, 3500));
		blocklist.add(new block(25, 4000));
		blocklist.add(new block(135, 4000));
		blocklist.add(new block(245, 4000));
		blocklist.add(new block(355, 4000));
		blocklist.add(new block(465, 4000));
		blocklist.add(new block(25, 4500));
		blocklist.add(new block(135, 4500));
		blocklist.add(new block(245, 4500));
		blocklist.add(new block(355, 4500));
		blocklist.add(new block(465, 4500));
		blocklist.add(new block(25, 5000));
		blocklist.add(new block(465, 6000));
		blocklist.add(new block(465, 7000));
		blocklist.add(new block(25, 8000));
		blocklist.add(new block(25, 9000));
		blocklist.add(new block(135, 10000));
		blocklist.add(new block(245, 11000));
		blocklist.add(new block(355, 12000));
		blocklist.add(new block(355, 13000));
		blocklist.add(new block(25, 14000));
		blocklist.add(new block(465, 15000));
		blocklist.add(new block(25, 16000));
		blocklist.add(new block(25, 17000));
		blocklist.add(new block(25, 18000));
		blocklist.add(new block(465, 19000));
		blocklist.add(new block(465, 20000));
		blocklist.add(new block(355, 21000));
		blocklist.add(new block(355, 22000));
		blocklist.add(new block(135, 23000));
		blocklist.add(new block(135, 24000));
		blocklist.add(new block(245, 25000));
		blocklist.add(new block(245, 26000));
		blocklist.add(new block(25, 27000));
		blocklist.add(new block(25, 28000));
		blocklist.add(new block(25, 29000));
		blocklist.add(new block(25, 30000));
	}
		
}
