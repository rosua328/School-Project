import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

// ���â
public class result extends JFrame {
	String g;
	JButton bt = new JButton("���ư���");

	result() {

		setTitle("���");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false); // ũ�����
		setSize(300, 300);
		setLocationRelativeTo(null); // �߾�
		setVisible(true);

		getContentPane().setLayout(null);

		re();

		JLabel lblNewLabel = new JLabel(g);
		lblNewLabel.setBounds(100, 40, 183, 179);
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 100));
		getContentPane().add(lblNewLabel);

		bt.setBounds(90, 220, 95, 23);
		getContentPane().add(bt);

		bt.addActionListener(new action());
	}

	class action implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// ���ư��� ��ư Ŭ�� �� �� ����â���� �̵�
			if (e.getSource() == bt) {
				
				DB db;
				db= new DB(3);
				String u= db.check_id;
				String o= db.check_music;
				int oo = db.check_score;
				
				
			if(u.equals(main.id) && o.equals(main.mu)) {
				if(main.score>oo) {
					tt();
				}
			}
				
				db = new DB(4);
			
				String i = db.check_id;
				String t = db.check_music;
				if(i.equals(main.id) && t.equals(main.mu)) {
					if(main.score>oo) {
					ri2();
					}
				}
				else {
				ri();
				
				}
				new musicseledt();
				dispose();
			}

		}

	}

	
	// ������ ���� ��� ���� ����
	public void re() {
		if (main.score >= 0 && main.score <= 1500) {
			g = "C";
		} else if (main.score > 1500 && main.score <= 3500) {
			g = "B";
		} else if (main.score > 3500) {
			g = "A";
		}
	}

	public void tt() {
		DB db; 
		
		// ����, ���̸�, ���ǵ� DB�� ����
		String insertString1 = "UPDATE score SET score='" + main.score + "' where idnew='" + main.id + "' && music_name='" + main.mu + "'" ;
		
		db = new DB(insertString1);
	}
	
	
	public void ri2() {
		DB db; 	
		// ����, ���̸�, ���ǵ� DB�� ����
		String insertString1 = "UPDATE gim SET level='" + g + "' where idgim='" + main.id + "' && music_name='" + main.mu + "'" ;
		
		db = new DB(insertString1);
	}
	
	
	// DB ���� �Է�
	public void ri() {
		DB db;

		String insertString1 = "INSERT INTO gim VALUES " + "('" + main.id + "', '" + g + "', '" + main.mu + "')";

		db = new DB(insertString1);
	}

}
