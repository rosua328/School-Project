import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.util.ArrayList;
import java.util.TimerTask;

import javax.swing.ImageIcon;

import java.util.Timer;
import java.util.TimerTask;

public class game {
	int i = 0;
	int go_out = 0;
	String title;
	ArrayList<block> blocklist = new ArrayList<>();
	
	PAINT_CHECK PC; // ������ ���� ó�� ��ü
	game_music g_mu;

	game(String title) {
		
		this.title = title;
main.score = 0;
		if (title.equals("Anchors")) { // Anchors�϶� ���� ����
			g_mu = new game_music(title + ".mp3", true);
			g_mu.start();
			drop();
		} else if (title.equals("Call")) {
			g_mu = new game_music(title + ".mp3", true);
			g_mu.start();
			drop();
		}
	}

	// �̹��� ����
	Image back_d = new ImageIcon("image/gameimage.jpg").getImage();
	Image back_f = new ImageIcon("image/gameimage.jpg").getImage();
	Image back_sp = new ImageIcon("image/gameimage.jpg").getImage();
	Image back_j = new ImageIcon("image/gameimage.jpg").getImage();
	Image back_k = new ImageIcon("image/gameimage.jpg").getImage();
	Image check_bar = new ImageIcon("image/check_bar.png").getImage();
	public static Image GOOD_D = new ImageIcon("").getImage();
	public static Image BAD_D = new ImageIcon("").getImage();
	public static Image MISS_D = new ImageIcon("").getImage();
	public static Image GOOD_F = new ImageIcon("").getImage();
	public static Image BAD_F = new ImageIcon("").getImage();
	public static Image MISS_F = new ImageIcon("").getImage();
	public static Image GOOD_SP = new ImageIcon("").getImage();
	public static Image BAD_SP = new ImageIcon("").getImage();
	public static Image MISS_SP = new ImageIcon("").getImage();
	public static Image GOOD_J = new ImageIcon("").getImage();
	public static Image BAD_J = new ImageIcon("").getImage();
	public static Image MISS_J = new ImageIcon("").getImage();
	public static Image GOOD_K = new ImageIcon("").getImage();
	public static Image BAD_K = new ImageIcon("").getImage();
	public static Image MISS_K = new ImageIcon("").getImage();

	
	// �׸� �׸���
	public void screenDraw(Graphics2D g) {
		g.drawImage(back_d, 25, 40, null);
		g.drawImage(back_f, 135, 40, null);
		g.drawImage(back_sp, 245, 40, null);
		g.drawImage(back_j, 355, 40, null);
		g.drawImage(back_k, 465, 40, null);
		g.drawImage(check_bar, 0, 350, null);

		g.drawString("D", 70, 370);
		g.drawString("F", 185, 370);
		g.drawString("SPACE", 275, 370);
		g.drawString("J", 405, 370);
		g.drawString("K", 515, 370);

		g.setFont(new Font("Elephant", Font.BOLD, 30));
		g.drawString(title, 200, 460);
		g.setFont(new Font("Elephant", Font.BOLD, 40));
		for (i = 0; i < blocklist.size(); i++) { // ���� �׸���
			block b;
			b = blocklist.get(i);

			if (b.check == false) {
				blocklist.remove(i);
				i--;
			} else {
				b.screenDraw(g);
			}

		}
// �� Ű�� ���� ���� �׸�
		g.drawImage(GOOD_D, 45, 330, null);
		g.drawImage(GOOD_F, 155, 330, null);
		g.drawImage(GOOD_SP, 265, 330, null);
		g.drawImage(GOOD_J, 375, 330, null);
		g.drawImage(GOOD_K, 485, 330, null);
		g.drawImage(BAD_D, 45, 330, null);
		g.drawImage(BAD_F, 155, 330, null);
		g.drawImage(BAD_SP, 265, 330, null);
		g.drawImage(BAD_J, 375, 330, null);
		g.drawImage(BAD_K, 485, 330, null);
		g.drawImage(MISS_D, 45, 330, null);
		g.drawImage(MISS_F, 155, 330, null);
		g.drawImage(MISS_SP, 265, 330, null);
		g.drawImage(MISS_J, 375, 330, null);
		g.drawImage(MISS_K, 485, 330, null);

	}

	// Ű���忡 �Է¿� ���� �׸� ��ȭ�� ���� ó��
	
	public void d() {

		back_d = new ImageIcon("image/johoy.jpg").getImage();
		ch(25);
	}

	public void f() {
		back_f = new ImageIcon("image/johoy.jpg").getImage();
		ch(135);
	}

	public void space() {
		back_sp = new ImageIcon("image/johoy.jpg").getImage();
		ch(245);
	}

	public void j() {
		back_j = new ImageIcon("image/johoy.jpg").getImage();
		ch(355);
	}

	public void k() {
		back_k = new ImageIcon("image/johoy.jpg").getImage();
		ch(465);
	}

	public void dr() {
		back_d = new ImageIcon("image/gameimage.jpg").getImage();
	}

	public void fr() {
		back_f = new ImageIcon("image/gameimage.jpg").getImage();
	}

	public void spacer() {
		back_sp = new ImageIcon("image/gameimage.jpg").getImage();
	}

	public void jr() {
		back_j = new ImageIcon("image/gameimage.jpg").getImage();
	}

	public void kr() {
		back_k = new ImageIcon("image/gameimage.jpg").getImage();
	}

	public void ch(int num) { // Ű���� �Է¿� ���� ��Ʈ ó��
		for (int v = 0; v < blocklist.size(); v++) {
			block a = blocklist.get(v);
			if (a.x == num) {
				if (a.y <= 400 && a.y > 300) { // ��Ʈ�� ���� ���� ����
					if (a.y < 330 && a.y > 300) { // ���� ����
						System.out.println("���");
						// x�� ��ġ�� ���� ���� ó��
						if (num == 25) {
							PC = new PAINT_CHECK(num, 2);
						} else if (num == 135) {
							PC = new PAINT_CHECK(num, 2);
						} else if (num == 245) {
							PC = new PAINT_CHECK(num, 2);
						} else if (num == 355) {
							PC = new PAINT_CHECK(num, 2);
						} else if (num == 465) {
							PC = new PAINT_CHECK(num, 2);
						}
						PC.start();
						main.score = main.score += 50;
					} else if (a.y <= 370 && a.y > 330) { // �� ����
						System.out.println("��");
						// x�� ��ġ�� ���� ���� ó��
						if (num == 25) {
							PC = new PAINT_CHECK(num, 1);
						} else if (num == 135) {
							PC = new PAINT_CHECK(num, 1);
						} else if (num == 245) {
							PC = new PAINT_CHECK(num, 1);
						} else if (num == 355) {
							PC = new PAINT_CHECK(num, 1);
						} else if (num == 465) {
							PC = new PAINT_CHECK(num, 1);
						}
						PC.start();
						main.score = main.score += 100;
					} else if (a.y <= 400 && a.y > 370) { // ���� ����
						System.out.println("���");
						// x�� ��ġ�� ���� ���� ó��
						if (num == 25) {
							PC = new PAINT_CHECK(num, 2);
						} else if (num == 135) {
							PC = new PAINT_CHECK(num, 2);
						} else if (num == 245) {
							PC = new PAINT_CHECK(num, 2);
						} else if (num == 355) {
							PC = new PAINT_CHECK(num, 2);
						} else if (num == 465) {
							PC = new PAINT_CHECK(num, 2);
						}
						PC.start();
						main.score = main.score += 50;
					}

					a.hit();

				}
			}
		}
	}

	public void drop() { // ��Ʈ�� ������
		note t = new note();
		note2 t2 = new note2();
		if (title.equals("Anchors")) { // ���� Anchors�� ���
			blocklist = t.blocklist;
		} else if (title.equals("Call")) { // ���� Call�� ���
			blocklist = t2.blocklist;
		}
		for (int i = 0; i < blocklist.size(); i++) { // ��Ʈ�� �ϳ��� ����
			block a;
			a = blocklist.get(i);
			a.start();
		}

	}

}
