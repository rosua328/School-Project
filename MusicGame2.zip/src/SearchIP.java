import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import java.io.*;
import java.net.*;

public class SearchIP extends JFrame { // ���̵� ��й�ȣ ã�� ����� �����ִ� GUI

	JButton b = new JButton("Ȯ��");

	SearchIP(String i) {

		String a = "";
		a = i;
		JLabel l = new JLabel(a + " �Դϴ�");

		setTitle("ã����");
		setLayout(new BorderLayout());

		this.setResizable(false);
		this.setLocationRelativeTo(null);

		setSize(150, 150);

		l.setHorizontalAlignment(JLabel.CENTER);

		add(l, BorderLayout.CENTER);
		add(b, BorderLayout.SOUTH);

		b.addActionListener(new action());
		setVisible(true);
	}

	class action implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (e.getSource() == b) {
				dispose();
			}
		}

	}

}